const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

function isAllowedYouTubeUrl(value) {
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase().replace(/^www\./, '');
    return ['youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be'].includes(host);
  } catch {
    return false;
  }
}

function safeFilename(value) {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9 _.-]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 100) || 'audio';
}

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { windowsHide: true });
    let stdout = '';
    let stderr = '';

    child.stdout.on('data', data => { stdout += data.toString(); });
    child.stderr.on('data', data => { stderr += data.toString(); });
    child.on('error', reject);
    child.on('close', code => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error(stderr || `O processo terminou com código ${code}.`));
    });
  });
}

app.post('/api/download', async (req, res) => {
  const { url, quality = '192' } = req.body || {};
  const allowedQualities = new Set(['128', '192', '320']);

  if (!isAllowedYouTubeUrl(url)) {
    return res.status(400).json({ error: 'Informe um link válido do YouTube.' });
  }

  if (!allowedQualities.has(String(quality))) {
    return res.status(400).json({ error: 'Qualidade de áudio inválida.' });
  }

  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'audio-'));
  const token = crypto.randomBytes(8).toString('hex');
  const outputTemplate = path.join(tempDir, `${token}.%(ext)s`);

  try {
    const metadata = await run('yt-dlp', [
      '--no-playlist',
      '--print', '%(title)s',
      '--skip-download',
      url
    ]);

    const title = safeFilename(metadata.stdout.trim().split('\n')[0]);

    await run('yt-dlp', [
      '--no-playlist',
      '--extract-audio',
      '--audio-format', 'mp3',
      '--audio-quality', `${quality}K`,
      '--output', outputTemplate,
      url
    ]);

    const files = fs.readdirSync(tempDir);
    const mp3File = files.find(file => file.endsWith('.mp3'));

    if (!mp3File) {
      throw new Error('O arquivo MP3 não foi criado.');
    }

    const filePath = path.join(tempDir, mp3File);
    res.download(filePath, `${title}.mp3`, error => {
      fs.rm(tempDir, { recursive: true, force: true }, () => {});
      if (error && !res.headersSent) {
        res.status(500).json({ error: 'Erro ao enviar o arquivo.' });
      }
    });
  } catch (error) {
    fs.rm(tempDir, { recursive: true, force: true }, () => {});
    console.error(error);
    res.status(500).json({
      error: 'Não foi possível converter. Confirme se yt-dlp e FFmpeg estão instalados e atualizados.'
    });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor aberto em http://localhost:${PORT}`);
});
