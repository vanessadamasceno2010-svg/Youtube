# Conversor local para MP3

Use somente em vídeos próprios, em domínio público ou com autorização do titular.

## Requisitos

- Node.js 18 ou superior
- yt-dlp
- FFmpeg

## Instalação no Windows

1. Instale o Node.js.
2. Instale o yt-dlp e deixe o comando `yt-dlp` disponível no PATH.
3. Instale o FFmpeg e deixe o comando `ffmpeg` disponível no PATH.
4. Abra o terminal dentro desta pasta.
5. Execute:

```bash
npm install
npm start
```

6. Abra no navegador:

```text
http://localhost:3000
```

## Observação

Um arquivo HTML aberto diretamente no navegador não consegue converter vídeos do YouTube sozinho. O arquivo `server.js` é responsável por processar o áudio localmente.
